# This code is used to convert an adjacency matrix to adjacency list
def mat_to_list(mat):
    adj = []
    for _ in range(len(mat)):
        adj.append([])
    for row in range(len(mat)):
        for col in range(len(mat)):
            if mat[row][col] == 1:
                adj[row].append(col)
    return adj

mat = [[0, 1, 1, 0], [1, 0, 1, 0], [1, 1, 0, 1], [0, 0, 1, 0]]
res = mat_to_list(mat)
print(res)
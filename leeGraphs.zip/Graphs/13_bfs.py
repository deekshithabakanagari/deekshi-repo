# This code works for both adj list with or without hashmap

from collections import deque

def bfs(adj_list, start):
    queue = deque([start])
    visited = {start}
    result = []

    while queue:
        temp = queue.popleft()
        result.append(temp)
        
        for node in adj_list[temp]:
            if node not in visited:
                queue.append(node)
                visited.add(node)
    
    return result

# Example usage
adj_list = {
    0: [2, 3, 1],
    1: [0],
    2: [0, 4],
    3: [0],
    4: [2]
}

# adj_list = [[2, 3, 1], [0], [0, 4], [0], [2]]

res = bfs(adj_list, 1)
print(res)
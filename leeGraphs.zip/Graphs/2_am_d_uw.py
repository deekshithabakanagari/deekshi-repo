# A function to add an edge to a directed graph's adj matrix
def add_edge(mat, i, j):
    mat[i][j] = 1

# A function to remove an edge from a directed graph's adj matrix
def remove_edge(mat, i, j):
    mat[i][j] = 0

def display_matrix(mat):
    for row in mat:
        print(row)
    print()

nodes = 4
mat = []
for i in range(nodes):
    mat.append([0] * nodes)
display_matrix(mat)

# Adding edges to the graph
add_edge(mat, 0, 1)
add_edge(mat, 1, 2)
add_edge(mat, 2, 3)
add_edge(mat, 3, 1)

display_matrix(mat)
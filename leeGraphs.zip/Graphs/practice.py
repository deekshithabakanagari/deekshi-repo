# A graph with n nodes has up to nC2 edges 
# and in our case the graph can have or not have particular edge so the total no. of undirected graph will be 2^(total edges)

# Defining the graph class with all the methods
class Graph:

    # The instance variables
    def __init__(self, directed=False):
        self.directed = directed
        self.adj_list = dict()

    # A method to represent the graph
    def __repr__(self):
        graph = ''
        for node, neighbors in self.adj_list:
            graph += f'{node} -> {neighbors}'
        return graph
    
    # A method to add a node to the graph
    def add_node(self, node):
        if node not in self.adj_list:
            self.adj_list[node] = set()
        else:
            raise ValueError('Node already exists')
        
    # A method to remove a node from the graph
    def remove_node(self, node):
        if node not in self.adj_list:
            raise ValueError('Node does not exist')
        
        for neighbor in self.adj_list.values():
            neighbor.discard(node)

        del self.adj_list[node]

    # A method to add an edge to a graph
    def add_edge(self, from_node, to_node, weight=None):
        
        # Creating the nodes if they don't exist
        if from_node not in self.adj_list:
            self.add_node(from_node)
        if to_node not in self.adj_list:
            self.add_node(to_node)
        
        # Creating the edges
        if not weight:
            self.adj_list[from_node].add(to_node)
            if not self.directed:
                self.adj_list[to_node].add(from_node)
        else:
            self.adj_list[from_node].add((to_node, weight))
            if not self.directed:
                self.adj_list[from_node].add((from_node, weight))

    # A method to remove an edge from a graph
    def remove_edge(self, from_node, to_node):
        if from_node in self.adj_list:
            if to_node in self.adj_list[from_node]:
                self.adj_list[from_node].remove(to_node)
            else:
                raise ValueError('Edge does not exist')

            if not self.directed:
                if from_node in self.adj_list[to_node]:
                    self.adj_list[to_node].remove(from_node)
            
        else:
            raise ValueError('Edge does not exist')
        
    # A method to get all the neighbors of a node
    def get_neighbors(self, node):
        return self.adj_list.get(node, set())
    
    # A method to check if a node exists in a graph
    def has_node(self, node):
        return node in self.adj_list
    
    # A method to check if an edge exists in a graph
    def has_edge(self, from_node, to_node):
        if from_node in self.adj_list:
            return to_node in self.adj_list[from_node]
        return False
    
    # A method to get all the nodes from a graph
    def get_nodes(self):
        return list(self.adj_list.keys())
    
    # A method to get all the edges from a graph
    def get_edges(self):
        edges = []
        for from_node, neighbors in self.adj_list:
            for to_node in neighbors:
                edges.append((from_node, to_node))
        return edges
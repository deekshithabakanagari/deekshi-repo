def add_edge(mat, i, j, weight):
    mat[i][j] = weight

def remove_edge(mat, i, j):
    mat[i][j] = float('inf')

def display_matrix(mat):
    for row in mat:
        print(row)
    print()

nodes = 5
mat = []
for i in range(nodes):
    mat.append([float('inf')] * nodes)
display_matrix(mat)

add_edge(mat, 0, 1, 5)
add_edge(mat, 1, 2, 7)
add_edge(mat, 1, 3, 10)
add_edge(mat, 2, 3, 3)
add_edge(mat, 3, 4, 6)
add_edge(mat, 4, 1, 2)

display_matrix(mat)
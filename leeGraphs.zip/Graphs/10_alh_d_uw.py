def add_edge(adj_list, i, j):
    if i in adj_list:
        adj_list[i].append(j)
    else:
        adj_list[i] = [j]


def remove_edge(adj_list, i, j):
    if i in adj_list:
        adj_list[i].remove(j)


def display_list(adj_list):
    for key in adj_list:
        print(f'{key}: {adj_list[key]}')
    print()


# Initialize the adjacency list as an empty dictionary
adj_list = {}

# Display the initial adjacency list
display_list(adj_list)

# Adding directed edges (i -> j)
add_edge(adj_list, 0, 1)
add_edge(adj_list, 1, 2)
add_edge(adj_list, 2, 0)

# Display the updated adjacency list
display_list(adj_list)
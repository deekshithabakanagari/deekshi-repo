class Graph:

    # The instance variables
    def __init__(self, directed=False):
        self.directed = directed
        self.adj_list = dict()

    # The method to represent a graph
    def __repr__(self):
        self.adj_list
        graph = ''
        for node in self.adj_list:
            graph += f'{node} -> {self.adj_list[node]}\n'
        return graph

    # The method to add nodes to a graph
    def add_node(self, node):
        if node not in self.adj_list:
            self.adj_list[node] = set()

    # The method to add edges to a graph
    def add_edges(self, from_node, to_node):
        
        if from_node not in self.adj_list:
            self.add_node(from_node)
        if to_node not in self.adj_list:
            self.add_node(to_node)

        self.adj_list[from_node].add(to_node)
        self.adj_list[to_node].add(from_node)

def print_graph(edges):
    pass

edges = [[0,3], [0,2], [2,1]]
print(print_graph(edges))

my_graph = Graph()
for i, j in edges:
    my_graph.add_edges(i, j)

print(my_graph)
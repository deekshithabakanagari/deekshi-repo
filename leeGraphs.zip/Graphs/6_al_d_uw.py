def add_edge(adj_list, i, j):
    adj_list[i].append(j)

def remove_edge(adj_list, i, j):
    adj_list[i].remove(j)

def display_list(adj_list):
    for i in range(len(adj_list)):
        print(f'{i}: {adj_list[i]}')
    print()

nodes = 3
adj_list = []
for i in range(nodes):
    adj_list.append([])
display_list(adj_list)

add_edge(adj_list, 1, 2)
add_edge(adj_list, 1, 0)
add_edge(adj_list, 2, 0)
display_list(adj_list)
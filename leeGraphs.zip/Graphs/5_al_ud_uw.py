# This code is for adj list of undirected, unweighted graph

# A function to add edge to adj list
def add_edge(adj_list, i, j):
    adj_list[i].append(j)
    adj_list[j].append(i)

# A function to remove an edge from adj list
def remove_edge(adj_list, i, j):
    adj_list[i].remove(j)
    adj_list[j].remove(i)

def display_list(adj_list):
    for i in range(len(adj_list)):
        print(f'{i}: {adj_list[i]}')
    print()

nodes = 3
adj_list = []
for i in range(nodes):
    adj_list.append([])
display_list(adj_list)

add_edge(adj_list, 0, 1)
add_edge(adj_list, 0, 2)
add_edge(adj_list, 1, 2)
display_list(adj_list)
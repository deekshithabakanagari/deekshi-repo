def add_edge(adj_list, i, j, weight):
    adj_list[i].append([j, weight])
    adj_list[j].append([i, weight])

def remove_edge(adj_list, i, j, weight):
    adj_list[i].remove([j, weight])
    adj_list[j].remove([i, weight])

def display_list(adj_list):
    for i in range(len(adj_list)):
        print(f'{i}: {adj_list[i]}')
    print()

nodes = 3
adj_list = []
for i in range(nodes):
    adj_list.append([])
display_list(adj_list)

add_edge(adj_list, 0, 1, 4)
add_edge(adj_list, 0, 2, 1)
add_edge(adj_list, 1, 2, 3)
display_list(adj_list)
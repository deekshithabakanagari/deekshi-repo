# This code works for both adj list with or without hashmap

def dfs(adj, s):
        
    visited = set()
    stack = [s]
    result = []
    
    while stack:
        temp = stack.pop()

        if temp not in visited:
            visited.add(temp)
            result.append(temp)
            
            for node in reversed(adj[temp]):
                if node not in visited:
                    stack.append(node)
    
    return result

# Example usage
# adj_list = {
#     0: [2, 3, 1],
#     1: [0],
#     2: [0, 4],
#     3: [0],
#     4: [2]
# }

adj_list = [[2, 3, 1], [0], [0, 4], [0], [2]]

res = dfs(adj_list, 0)
print(res)
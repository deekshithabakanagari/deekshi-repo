# A function to add node to a weighted graph's adj matrix
def add_edge(mat, i, j, weight=1):
    mat[i][j] = weight
    mat[j][i] = weight

# A function to remove node from a weighted graph's adj matrix
def remove_edge(mat, i, j):
    mat[i][j] = float('inf')
    mat[j][i] = float('inf')

# A function to display a matrix
def display_matrix(mat):
    for row in mat:
        print(row)
    print()

nodes = 5
mat = []
for i in range(nodes):
    mat.append([float('inf')] * nodes)

display_matrix(mat)

# Adding edges to the matrix
add_edge(mat, 0, 1, 5)
add_edge(mat, 1, 2, 7)
add_edge(mat, 1, 3, 10)
add_edge(mat, 2, 3, 3)
add_edge(mat, 3, 4, 6)

display_matrix(mat)

remove_edge(mat, 0, 1)

display_matrix(mat)
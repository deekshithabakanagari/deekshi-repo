# This code is for adding and removing edge for adjacency matrix
# There is no method to add and remove node in adjacency matrix

# A function to add an edge in a graph
def add_edge(mat, i, j):
    mat[i][j] = 1
    mat[j][i] = 1

# A function to remove an edge from a graph
def remove_edge(mat, i, j):
    mat[i][j] = 0
    mat[j][i] = 0

# A function to print the adj matrix
def display_matrix(mat):
    for row in mat:
        print(row)

# Creating an empty adj matrix
nodes = 4

mat = []
for i in range(nodes):
    mat.append([0] * nodes)

display_matrix(mat)

# Adding edges to the graph
add_edge(mat, 0, 1)
add_edge(mat, 0, 2)
add_edge(mat, 1, 2)
add_edge(mat, 2, 3)

print()
add_edge(mat, 1, 3)
display_matrix(mat)

remove_edge(mat, 1, 3)

print()
display_matrix(mat)
# A class for graphs with all the methods
class Graph:

    # The instance method
    def __init__(self, directed=False):
        self.directed = directed
        self.adj_list = dict()

    # The method to represent a graph
    def __repr__(self):
        graph = ''
        for node in self.adj_list:
            graph += f'{node} -> {self.adj_list[node]}\n'
        return graph
    
    # A method to add a node to the graph
    def add_node(self, node):
        if node not in self.adj_list:
            self.adj_list[node] = set()
        else:
            raise ValueError('Node already exists')
        
    # A method to remove a node from a graph
    def remove_node(self, node):
        if node not in self.adj_list:
            raise ValueError('Node does not exist')
        
        for neighbor in self.adj_list.values():
            neighbor.discard(node)

        del self.adj_list[node]

    # A method to add an edge to a graph
    def add_edge(self, from_node, to_node, weight=None):

        # Creating the nodes if they don't exist
        if from_node not in self.adj_list:
            self.add_node(from_node)
        if to_node not in self.adj_list:
            self.add_node(to_node)

        # Creating the edge
        if not weight:
            self.adj_list[from_node].add(to_node)
            if not self.directed:
                self.adj_list[to_node].add(from_node)

        else:
            self.adj_list[from_node].add((to_node, weight))
            if not self.directed:
                self.adj_list[to_node].add(from_node, weight)

    # A method to remove an edge from a graph
    def remove_edge(self, from_node, to_node):
        if from_node in self.adj_list:
            if to_node in self.adj_list[from_node]:
                self.adj_list[from_node].remove(to_node)
            else:
                raise ValueError('Edge does not exist')
            
            if not self.directed:
                if from_node in self.adj_list[to_node]:
                    self.adj_list[to_node].remove(from_node)

        else:
            raise ValueError('Edge does not exist')
        
    # A method to get the neighbors of a given node
    def get_neighbors(self, node):
        return self.adj_list.get(node, set())
    
    # A method to check if a node exists in a graph
    def has_node(self, node):
        return node in self.adj_list
    
    # A method to check if an edge exists in a graph
    def has_edge(self, from_node, to_node):
        if from_node in self.adj_list:
            return to_node in self.adj_list[from_node]
        return False
    
    # A method to get all the nodes from a graph
    def get_nodes(self):
        return list(self.adj_list.keys())
    
    # A method to get all the edges from a graph
    def get_edges(self):
        edges = []
        for from_node, neighbors in self.adj_list:
            for to_node in neighbors:
                edges.append((from_node, to_node))
        return edges
    
    # A method for bfs
    def bfs(self, start):
        visited = set()
        queue = [start]
        order = []

        while queue:
            node = queue.pop(0)
            if node not in visited:
                visited.add(node)
                order.append(node)
                neighbors = self.get_neighbors(node)
                for neighbor in neighbors:
                    if isinstance(neighbor, tuple):
                        neighbor = neighbor[0]
                    if neighbor not in visited:
                        queue.append(neighbor)
        
        return order

    # A method for dfs
    def dfs(self, start):
        visited = set()
        stack = [start]
        order = []

        while stack:
            node = stack.pop()
            if node not in visited:
                visited.add(node)
                order.append(node)
                neighbors = self.get_neighbors(node)
                for neighbor in sorted(neighbors, reverse=True):
                    if isinstance(neighbor, tuple):
                        neighbor = neighbor[0]
                    if neighbor not in visited:
                        stack.append(neighbor)
        
        return order
    
    # A method to convert edge list to adjacency list
    def edgeList_adjList(self, edgeList):
        from collections import defaultdict
        adjList = defaultdict(list)
        for u, v in edgeList:
            adjList[u].append(v)
            adjList[v].append(u)
        return adjList

    # A method to convert adjacency list to adjacency matrix
    def adjList_adjMatrix(self, adjList):
        adjMatrix = [[0] * len(adjList) for i in range(len(adjList))]
        for i in adjList:
            for j in adjList[i]:
                adjMatrix[i][j] = 1
        for i in adjMatrix:
            print(i)
    

# The implementation seems good so far
# Let's try adding some nodes and edges and create a graph

# The creation can be done by just adding the edges since it automatically creates nodes

# There are four edges in our graph
my_graph = Graph()
my_graph.add_edge(1, 2)
my_graph.add_edge(1, 3)
my_graph.add_edge(2, 5)
my_graph.add_edge(2, 6)
my_graph.add_edge(3, 4)
my_graph.add_edge(3, 7)
my_graph.add_edge(4, 8)
my_graph.add_edge(7, 8)

# Need to do a dfs to verify whether the graph has been created correctly
# res = my_graph.dfs(3)
# print(res)

# # Doing a bfs on the graph
# res = my_graph.bfs(3)
# print(res)

# my_graph.adjList_adjMatrix({0: [1, 4], 1: [0, 2, 3, 4], 4: [0, 1, 3], 2: [1, 3], 3: [1, 2, 4]})
print(my_graph)

# The code is working good

# Now I need to learn bigger algorithms like -
# - depth first search
# - breadth first search
# - union find
# - topological sort
# - dijkstra's algorithm
# - prim's algorithm
# - kruskal's algorithm
# - floyd warshall algorithm
# - bellman - ford algorithm
# - ford - fulkerson algorithm
# - kosaraju's algorithm
def dfs(adj, s, visited):
    stack = [s]
    visited[s] = True
    
    while stack:
        curr = stack.pop()
        print(curr, end=" ")

        for x in adj[curr]:
            if not visited[x]:
                stack.append(x)
                visited[x] = True

def dfs_disconnected(adj, v):
    visited = [False] * v
    for i in range(v):
        if not visited[i]:
            dfs(adj, i, visited)

def add_edge(adj, u, v):
    adj[u].append(v)
    adj[v].append(u)

v = 6  # Number of vertices
adj = [[] for _ in range(v)]

# Add edges to the graph
add_edge(adj, 0, 1)
add_edge(adj, 0, 2)
add_edge(adj, 3, 4)
add_edge(adj, 4, 5)

# Perform DFS traversal for the entire graph
dfs_disconnected(adj, 3)
n = int(input())
nums = list(map(int, input().split()))
cur = nums[0]
res = [1]
for i in range(1, len(nums)):
    if nums[i] > cur:
        res.append(1)
        cur = nums[i]
    else:
        res.append(0)
print(res)
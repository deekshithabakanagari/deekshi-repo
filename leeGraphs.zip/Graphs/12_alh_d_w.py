def add_edge(adj_list, i, j, weight):
    if i in adj_list:
        adj_list[i].append((j, weight))
    else:
        adj_list[i] = [(j, weight)]


def remove_edge(adj_list, i, j, weight):
    if i in adj_list:
        adj_list[i].remove((j, weight))


def display_list(adj_list):
    for key in adj_list:
        print(f'{key}: {adj_list[key]}')
    print()


# Initialize the adjacency list as an empty dictionary
adj_list = {}

# Adding directed edges (i -> j with weight)
add_edge(adj_list, 0, 1, 4)
add_edge(adj_list, 1, 2, 3)
add_edge(adj_list, 2, 0, 1)

# Display the adjacency list
display_list(adj_list)